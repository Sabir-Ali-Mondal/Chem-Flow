
import React, { useState, useCallback, useRef, useEffect } from 'react';
import { MechanismData } from './types';
import P5Canvas from './components/P5Canvas';
import { analyzeReaction } from './services/gemini';

const App: React.FC = () => {
  const [mechanismData, setMechanismData] = useState<MechanismData | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isRefineModalOpen, setIsRefineModalOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<'ai' | 'json'>('ai');
  const [jsonInput, setJsonInput] = useState('');
  const [reactionPrompt, setReactionPrompt] = useState('');
  const [refinementFeedback, setRefinementFeedback] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [crop, setCrop] = useState({ x: 10, y: 10, w: 80, h: 80 });
  const [isResizing, setIsResizing] = useState<string | null>(null);
  
  const imageRef = useRef<HTMLImageElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (ev) => {
        setUploadedImage(ev.target?.result as string);
        setCrop({ x: 10, y: 10, w: 80, h: 80 });
      };
      reader.readAsDataURL(file);
    }
  };

  const getCroppedImage = (): string | undefined => {
    if (uploadedImage && imageRef.current) {
      const canvas = document.createElement('canvas');
      const img = imageRef.current;
      const rect = img.getBoundingClientRect();
      const scaleX = img.naturalWidth / rect.width;
      const scaleY = img.naturalHeight / rect.height;
      const cx = (crop.x / 100) * rect.width * scaleX;
      const cy = (crop.y / 100) * rect.height * scaleY;
      const cw = (crop.w / 100) * rect.width * scaleX;
      const ch = (crop.h / 100) * rect.height * scaleY;
      canvas.width = cw; canvas.height = ch;
      const ctx = canvas.getContext('2d');
      if (ctx) { 
        ctx.drawImage(img, cx, cy, cw, ch, 0, 0, cw, ch); 
        return canvas.toDataURL('image/png'); 
      }
    }
    return undefined;
  };

  const handleAIAnalyze = async (isRefining: boolean = false) => {
    if (!reactionPrompt && !uploadedImage && !isRefining) return alert("Describe the reaction or upload an image.");
    setIsAnalyzing(true);
    
    const finalImage = getCroppedImage();
    const result = await analyzeReaction(
      reactionPrompt, 
      finalImage, 
      isRefining ? (mechanismData || undefined) : undefined, 
      isRefining ? refinementFeedback : undefined
    );
    
    setIsAnalyzing(false);
    
    if (result) { 
      setMechanismData(result); 
      setJsonInput(JSON.stringify(result, null, 2)); 
      setIsModalOpen(false);
      setIsRefineModalOpen(false);
      setRefinementFeedback('');
    } else { 
      alert("AI Analysis failed. Please try a different prompt or clearer image."); 
    }
  };

  const onMove = (e: MouseEvent | TouchEvent) => {
    if (!isResizing || !containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const clientX = 'touches' in e ? e.touches[0].clientX : (e as MouseEvent).clientX;
    const clientY = 'touches' in e ? e.touches[0].clientY : (e as MouseEvent).clientY;
    const px = ((clientX - rect.left) / rect.width) * 100;
    const py = ((clientY - rect.top) / rect.height) * 100;

    setCrop(prev => {
      let next = { ...prev };
      if (isResizing === 'move') {
        next.x = Math.max(0, Math.min(px - prev.w/2, 100 - prev.w));
        next.y = Math.max(0, Math.min(py - prev.h/2, 100 - prev.h));
      } else if (isResizing === 'br') {
        next.w = Math.max(5, Math.min(px - prev.x, 100 - prev.x));
        next.h = Math.max(5, Math.min(py - prev.y, 100 - prev.y));
      }
      return next;
    });
  };

  useEffect(() => {
    const handleUp = () => setIsResizing(null);
    window.addEventListener('mouseup', handleUp);
    window.addEventListener('touchend', handleUp);
    window.addEventListener('mousemove', onMove);
    window.addEventListener('touchmove', onMove);
    return () => {
      window.removeEventListener('mouseup', handleUp); window.removeEventListener('touchend', handleUp);
      window.removeEventListener('mousemove', onMove); window.removeEventListener('touchmove', onMove);
    };
  }, [isResizing]);

  return (
    <div className="min-h-screen bg-[#05070a] text-slate-100">
      <header className="fixed top-0 w-full z-[100] px-6 py-4 bg-[#05070a]/80 backdrop-blur-xl border-b border-white/5 flex justify-between items-center">
        <div className="flex items-center gap-3 cursor-pointer" onClick={() => window.location.reload()}>
          <i className="bi bi-virus text-violet-500 text-2xl"></i>
          <span className="font-black text-lg tracking-tighter uppercase">Chem Lab <span className="text-violet-500">Canvas</span></span>
        </div>
        <button onClick={() => setIsModalOpen(true)} className="px-6 py-2 bg-violet-600 hover:bg-violet-500 text-white rounded-full transition-all font-bold shadow-lg text-sm flex items-center gap-2">
          <i className="bi bi-cpu"></i> Studio
        </button>
      </header>

      <main className="max-w-5xl mx-auto pt-28 px-6 pb-20">
        {!mechanismData ? (
          <div className="flex flex-col items-center justify-center text-center mt-20 animate-in fade-in zoom-in duration-700">
            <div className="w-32 h-32 rounded-3xl bg-violet-500/10 flex items-center justify-center mb-8 border border-violet-500/20 shadow-[0_0_80px_rgba(124,58,237,0.15)]">
              <i className="bi bi-bezier2 text-6xl text-violet-500/40"></i>
            </div>
            <h1 className="text-5xl md:text-7xl font-black mb-6 tracking-tighter leading-tight">Visualizing The Unseen.</h1>
            <p className="text-slate-400 text-lg md:text-xl max-w-2xl mb-12 font-medium opacity-80">
              Paste a reaction name or upload a scan to generate fluid molecular simulations powered by Gemini Flash.
            </p>
            <button onClick={() => setIsModalOpen(true)} className="px-10 py-5 bg-violet-600 hover:bg-violet-700 text-white rounded-2xl font-black text-xl shadow-xl transition-transform hover:-translate-y-1">
              Start Simulation
            </button>
          </div>
        ) : (
          <div className="animate-in fade-in slide-in-from-bottom-8 duration-700">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-12 border-b border-white/5 pb-8 gap-6">
              <div>
                <div className="flex items-center gap-3 mb-2">
                  <button 
                    onClick={() => setIsRefineModalOpen(true)} 
                    className="group flex items-center gap-2 px-3 py-1 bg-violet-600/20 hover:bg-violet-600/30 text-violet-400 rounded-lg transition-all border border-violet-500/20 font-bold text-[10px] uppercase tracking-wider"
                  >
                    <i className="bi bi-arrow-clockwise group-hover:rotate-180 transition-transform duration-500"></i> Retry / Refine
                  </button>
                  <span className="text-slate-500 font-bold uppercase tracking-widest text-[10px] block">Live Rendering</span>
                </div>
                <h1 className="text-3xl md:text-5xl font-black text-white tracking-tighter">
                  {mechanismData.meta?.reactionName || 'Unnamed Reaction'}
                </h1>
              </div>
              <div className="flex gap-3">
                <button onClick={() => setMechanismData(null)} className="flex items-center gap-2 px-5 py-2.5 bg-white/5 hover:bg-red-500/10 hover:text-red-400 rounded-xl transition-all border border-white/5 font-bold text-xs">
                  <i className="bi bi-trash"></i> Reset
                </button>
              </div>
            </div>
            {mechanismData.mechanism?.map((step, idx) => (
              <P5Canvas key={idx} index={idx} step={step} data={mechanismData} />
            ))}
          </div>
        )}
      </main>

      {/* Refine Modal */}
      {isRefineModalOpen && (
        <div className="fixed inset-0 z-[1100] flex items-center justify-center bg-black/95 backdrop-blur-xl p-4">
          <div className="bg-[#0b0d11] border border-white/10 w-full max-w-lg rounded-[2.5rem] p-8 shadow-2xl animate-in zoom-in-95 duration-200">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-black tracking-tight">Refine Simulation</h2>
              <button onClick={() => setIsRefineModalOpen(false)} className="text-slate-500 hover:text-white"><i className="bi bi-x-lg"></i></button>
            </div>
            <p className="text-slate-400 text-sm mb-6 leading-relaxed">Describe what's wrong with the current simulation (e.g., "Atoms are overlapping", "Wrong leaving group", "Arrow direction is reversed"). Leave empty to let AI find improvements.</p>
            <textarea 
              className="w-full h-32 bg-black/40 border border-white/10 rounded-2xl p-4 text-white focus:border-violet-500 outline-none transition mb-8 resize-none font-medium" 
              placeholder="How can we make this better? (optional)..."
              value={refinementFeedback}
              onChange={(e) => setRefinementFeedback(e.target.value)}
            />
            <div className="flex flex-col gap-3">
              <button 
                disabled={isAnalyzing}
                onClick={() => handleAIAnalyze(true)} 
                className={`w-full py-4 rounded-xl font-black text-lg transition-all ${isAnalyzing ? 'bg-slate-800 text-slate-600' : 'bg-violet-600 hover:bg-violet-500 text-white active:scale-95'}`}
              >
                {isAnalyzing ? <span className="flex items-center justify-center gap-2"><i className="bi bi-arrow-repeat animate-spin"></i> Refining...</span> : 'Update Mechanism'}
              </button>
              <button onClick={() => setIsRefineModalOpen(false)} className="w-full py-4 bg-white/5 hover:bg-white/10 text-white rounded-xl font-bold transition-all">Go Back</button>
            </div>
          </div>
        </div>
      )}

      {isModalOpen && (
        <div className="fixed inset-0 z-[1000] flex items-center justify-center bg-black/90 backdrop-blur-md p-4">
          <div className="bg-[#0b0d11] border border-white/10 w-full max-w-5xl h-[85vh] rounded-[2.5rem] overflow-hidden flex flex-col shadow-2xl">
            <div className="px-8 py-6 border-b border-white/5 flex justify-between items-center">
              <div className="flex gap-8">
                <button onClick={() => setActiveTab('ai')} className={`text-sm font-bold uppercase tracking-widest ${activeTab === 'ai' ? 'text-violet-500' : 'text-slate-500'}`}>AI Designer</button>
                <button onClick={() => setActiveTab('json')} className={`text-sm font-bold uppercase tracking-widest ${activeTab === 'json' ? 'text-violet-500' : 'text-slate-500'}`}>JSON Architect</button>
              </div>
              <button onClick={() => setIsModalOpen(false)} className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-red-500/10"><i className="bi bi-x-lg"></i></button>
            </div>

            <div className="flex-1 overflow-y-auto p-8">
              {activeTab === 'ai' ? (
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 h-full">
                  <div className="flex flex-col gap-6">
                    <div className="flex flex-col gap-2">
                      <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-2">Reaction Title / Prompt</label>
                      <input type="text" placeholder="e.g. SN2 Reaction of CH3Br with OH-" className="w-full bg-black/40 border border-white/10 rounded-2xl px-6 py-4 focus:border-violet-500 outline-none transition text-white font-bold" value={reactionPrompt} onChange={e => setReactionPrompt(e.target.value)} />
                    </div>
                    
                    <div className="flex-1 flex flex-col gap-2">
                      <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-2">Image Reference (Optional)</label>
                      <div className="relative flex-1 bg-black/40 rounded-2xl border border-white/5 border-dashed overflow-hidden min-h-[250px] group" ref={containerRef}>
                        {uploadedImage ? (
                          <div className="h-full w-full relative touch-none select-none flex items-center justify-center">
                            <img ref={imageRef} src={uploadedImage} alt="Crop Source" className="max-w-full max-h-full object-contain opacity-40" />
                            <div className="absolute border-2 border-violet-500 shadow-lg cursor-move" style={{ left: `${crop.x}%`, top: `${crop.y}%`, width: `${crop.w}%`, height: `${crop.h}%` }} onMouseDown={() => setIsResizing('move')} onTouchStart={() => setIsResizing('move')}>
                              <div className="absolute -bottom-2 -right-2 w-6 h-6 bg-violet-500 rounded-full cursor-nwse-resize border-4 border-black" onMouseDown={(e) => { e.stopPropagation(); setIsResizing('br'); }}></div>
                            </div>
                          </div>
                        ) : (
                          <label className="absolute inset-0 flex flex-col items-center justify-center cursor-pointer hover:bg-violet-500/5 transition-all text-center">
                            <i className="bi bi-image text-4xl text-slate-700 mb-4"></i>
                            <span className="text-slate-500 font-bold text-xs uppercase tracking-widest">Upload Schematic</span>
                            <input type="file" className="hidden" accept="image/*" onChange={handleFileUpload} />
                          </label>
                        )}
                        {uploadedImage && <button onClick={() => setUploadedImage(null)} className="absolute top-4 right-4 p-2 bg-red-500/20 text-red-400 rounded-lg backdrop-blur-md"><i className="bi bi-trash"></i></button>}
                      </div>
                    </div>
                  </div>

                  <div className="bg-slate-950/50 p-8 rounded-3xl border border-white/5 flex flex-col justify-center">
                    <div className="w-16 h-16 bg-violet-600/10 rounded-2xl flex items-center justify-center mb-6">
                       <i className="bi bi-magic text-3xl text-violet-500"></i>
                    </div>
                    <h3 className="text-2xl font-black text-white mb-4 tracking-tighter">Process Logic</h3>
                    <p className="text-slate-400 text-sm mb-10 font-medium">Gemini will resolve your input into a step-by-step kinetic simulation with curly arrows and accurate geometry.</p>
                    <button disabled={isAnalyzing} onClick={() => handleAIAnalyze(false)} className={`w-full py-5 rounded-2xl font-black text-xl transition-all ${isAnalyzing ? 'bg-slate-800 text-slate-600' : 'bg-violet-600 hover:bg-violet-500 text-white active:scale-95'}`}>
                      {isAnalyzing ? <span className="animate-pulse">Analyzing...</span> : 'Generate Mechanism'}
                    </button>
                  </div>
                </div>
              ) : (
                <div className="h-full flex flex-col gap-4">
                  <textarea className="flex-1 w-full bg-black/40 rounded-2xl border border-white/10 p-6 text-emerald-400 font-mono text-sm resize-none outline-none" placeholder='{ "meta": {...}, "molecules": {...}, "mechanism": [...] }' value={jsonInput} onChange={e => setJsonInput(e.target.value)} />
                  <button onClick={() => { try { setMechanismData(JSON.parse(jsonInput)); setIsModalOpen(false); } catch { alert('Invalid JSON Structure.'); } }} className="w-full py-4 bg-emerald-600 hover:bg-emerald-500 text-white font-black rounded-xl transition-all">Deploy Logic</button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default App;
