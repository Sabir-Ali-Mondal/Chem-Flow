
import React, { useEffect, useRef } from 'react';
import { MechanismStep, MechanismData, Vector2D, Molecule, Atom, Bond } from '../types';

declare const p5: any;

interface P5CanvasProps {
  step: MechanismStep;
  data: MechanismData;
  index: number;
}

const getPos = (p: Vector2D | undefined): { x: number; y: number } => {
  if (!p) return { x: 0, y: 0 };
  if (Array.isArray(p)) return { x: p[0], y: p[1] };
  return { x: p.x || 0, y: p.y || 0 };
};

const P5Canvas: React.FC<P5CanvasProps> = ({ step, data, index }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const p5InstanceRef = useRef<any>(null);

  useEffect(() => {
    if (!containerRef.current || !data) return;

    const sketch = (p: any) => {
      const getStepEndState = (stepIdx: number) => {
        let state: { [key: string]: Molecule } = JSON.parse(JSON.stringify(data.molecules || {}));
        if (!data.mechanism) return state;
        
        for (let i = 0; i < stepIdx; i++) {
          const s = data.mechanism[i];
          if (s?.resultingState?.molecules) {
            Object.entries(s.resultingState.molecules).forEach(([molId, override]) => {
              if (!state[molId]) state[molId] = { position: [0,0], atoms: [], bonds: [] };
              const mol = state[molId];
              if (override.hidden !== undefined) mol.hidden = override.hidden;
              if (override.position !== undefined) mol.position = override.position as any;
              if (override.atoms) {
                override.atoms.forEach(aO => {
                  const atom = mol.atoms.find(a => a.id === aO.id);
                  if (atom) Object.assign(atom, aO);
                  else if (aO.id) mol.atoms.push(aO as any);
                });
              }
              if (override.bonds) {
                override.bonds.forEach(bO => {
                  const bond = mol.bonds.find(b => (b.from === bO.from && b.to === bO.to) || (b.from === bO.to && b.to === bO.from));
                  if (bond) Object.assign(bond, bO);
                  else if (bO.from && bO.to) mol.bonds.push(bO as any);
                });
              }
            });
          }
        }
        return state;
      };

      let initialMolecules = getStepEndState(index);
      let targetMolecules = getStepEndState(index + 1);
      let bounds = { minX: 0, maxX: 0, minY: 0, maxY: 0 };
      
      p.view = { zoom: 1, panX: 0, panY: 0, dragging: false, lastX: 0, lastY: 0 };

      p.setup = () => {
        const rect = containerRef.current!.getBoundingClientRect();
        p.createCanvas(rect.width, rect.height);
        calcBounds();
        p.resetView();
      };

      const calcBounds = () => {
        let xs: number[] = [], ys: number[] = [];
        (step?.displayMolecules || []).forEach(k => {
          const m = targetMolecules[k];
          if (!m || m.hidden) return;
          const molPos = getPos(m.position);
          (m.atoms || []).forEach((a: Atom) => {
            if (!a || a.hidden) return;
            const atomPos = getPos(a.position);
            xs.push(atomPos.x + molPos.x);
            ys.push(atomPos.y + molPos.y);
          });
        });
        if (xs.length === 0) { xs = [-150, 150]; ys = [-150, 150]; }
        bounds = { minX: Math.min(...xs), maxX: Math.max(...xs), minY: Math.min(...ys), maxY: Math.max(...ys) };
      };

      p.resetView = () => {
        const w = (bounds.maxX - bounds.minX) || 200;
        const h = (bounds.maxY - bounds.minY) || 200;
        const padding = 150;
        const fitZoom = Math.min(p.width / (w + padding), p.height / (h + padding));
        p.view.zoom = fitZoom;
        p.view.panX = (p.width / 2) - (((bounds.minX + bounds.maxX) / 2) * fitZoom);
        p.view.panY = (p.height / 2) - (((bounds.minY + bounds.maxY) / 2) * fitZoom);
      };

      // Mouse/Touch Interaction
      p.mousePressed = () => {
        if (p.mouseX > 0 && p.mouseX < p.width && p.mouseY > 0 && p.mouseY < p.height) {
          p.view.dragging = true;
          p.view.lastX = p.mouseX;
          p.view.lastY = p.mouseY;
        }
      };
      p.mouseReleased = () => p.view.dragging = false;
      p.mouseDragged = () => {
        if (p.view.dragging) {
          p.view.panX += (p.mouseX - p.view.lastX);
          p.view.panY += (p.mouseY - p.view.lastY);
          p.view.lastX = p.mouseX;
          p.view.lastY = p.mouseY;
        }
      };
      p.mouseWheel = (event: WheelEvent) => {
        const scaleFactor = event.deltaY > 0 ? 0.9 : 1.1;
        p.view.zoom *= scaleFactor;
        return false;
      };

      p.draw = () => {
        p.background(5, 7, 10);
        p.push();
        p.translate(p.view.panX, p.view.panY);
        p.scale(p.view.zoom);

        const progress = (p.millis() % 4000) / 4000;
        const ease = 0.5 - Math.cos(progress * p.PI) / 2;

        (step?.displayMolecules || []).forEach(key => {
          const startMol = initialMolecules[key];
          const endMol = targetMolecules[key];
          if (!startMol || !endMol) return;

          const startOff = getPos(startMol.position);
          const endOff = getPos(endMol.position);
          const curOff = { x: p.lerp(startOff.x, endOff.x, ease), y: p.lerp(startOff.y, endOff.y, ease) };

          // Render Bonds with Glow
          (startMol.bonds || []).forEach((b: Bond) => {
            const endB = endMol.bonds?.find(eb => (eb.from === b.from && eb.to === b.to) || (eb.from === b.to && eb.to === b.from));
            if (b.hidden && (!endB || endB.hidden)) return;

            const a1s = startMol.atoms?.find(a => a.id === b.from);
            const a2s = startMol.atoms?.find(a => a.id === b.to);
            const a1e = endMol.atoms?.find(a => a.id === b.from);
            const a2e = endMol.atoms?.find(a => a.id === b.to);

            if (a1s && a2s && a1e && a2e) {
              const p1s = getPos(a1s.position); const p2s = getPos(a2s.position);
              const p1e = getPos(a1e.position); const p2e = getPos(a2e.position);
              const p1 = { x: p.lerp(p1s.x, p1e.x, ease) + curOff.x, y: p.lerp(p1s.y, p1e.y, ease) + curOff.y };
              const p2 = { x: p.lerp(p2s.x, p2e.x, ease) + curOff.x, y: p.lerp(p2s.y, p2e.y, ease) + curOff.y };
              
              const op = p.lerp(b.hidden ? 0 : 100, (endB?.hidden) ? 0 : 100, ease);
              p.stroke(255, op); p.strokeWeight(3.5);
              
              if (b.type === 'double') {
                p.line(p1.x - 3, p1.y - 3, p2.x - 3, p2.y - 3);
                p.line(p1.x + 3, p1.y + 3, p2.x + 3, p2.y + 3);
              } else if (b.type === 'triple') {
                p.line(p1.x - 5, p1.y - 5, p2.x - 5, p2.y - 5);
                p.line(p1.x, p1.y, p2.x, p2.y);
                p.line(p1.x + 5, p1.y + 5, p2.x + 5, p2.y + 5);
              } else {
                p.line(p1.x, p1.y, p2.x, p2.y);
              }
            }
          });

          // Render Atoms/Groups
          (startMol.atoms || []).forEach((a: Atom) => {
            const endA = endMol.atoms?.find(ea => ea.id === a.id);
            if (!endA) return;
            if (a.hidden && endA.hidden) return;

            const pStart = getPos(a.position); const pEnd = getPos(endA.position);
            const x = p.lerp(pStart.x, pEnd.x, ease) + curOff.x;
            const y = p.lerp(pStart.y, pEnd.y, ease) + curOff.y;
            const op = p.lerp(a.hidden ? 0 : 255, endA.hidden ? 0 : 255, ease);
            
            p.noStroke();
            const label = a.element || "C";
            const nodeSize = label.length > 2 ? 45 : 34;

            if (a.color) { 
              const c = a.color.split(',').map(v => parseInt(v.trim())); 
              p.fill(c[0]||100, c[1]||100, c[2]||100, op); 
            } else {
              if (label === 'C') p.fill(40, 44, 52, op); 
              else if (label === 'O') p.fill(239, 68, 68, op);
              else if (label === 'N') p.fill(59, 130, 246, op); 
              else if (label === 'H') p.fill(241, 245, 249, op);
              else p.fill(168, 85, 247, op);
            }

            p.ellipse(x, y, nodeSize);
            p.fill(label === 'H' ? 0 : 255, op);
            p.textAlign(p.CENTER, p.CENTER);
            p.textSize(label.length > 3 ? 10 : 13);
            p.textStyle(p.BOLD);
            p.text(label, x, y);

            if (a.charge) { 
              p.textSize(11); 
              p.fill(a.charge > 0 ? 239 : 59, a.charge > 0 ? 68 : 130, a.charge > 0 ? 68 : 246, op); 
              p.text(a.charge > 0 ? '+' : '-', x + 16, y - 16); 
            }
          });
        });

        // Curly Arrows with better curve
        if (Array.isArray(step?.animationHints)) {
          const t = (p.millis() % 2500) / 2500;
          step.animationHints.forEach(h => {
             if (h?.type === 'curlyArrow') {
                const getG = (s: string) => {
                  const parts = s.split(':'); if (parts.length < 2) return null;
                  const mol = targetMolecules[parts[0]]; if (!mol) return null;
                  const at = mol.atoms?.find((a: Atom) => a.id === parts[1]); if (!at) return null;
                  const mp = getPos(mol.position); const ap = getPos(at.position);
                  return { x: mp.x + ap.x, y: mp.y + ap.y };
                };
                const start = getG(h.from); const end = getG(h.to);
                if (start && end) {
                   p.noFill(); p.stroke(139, 92, 246, 200); p.strokeWeight(2.5);
                   const dist = p.dist(start.x, start.y, end.x, end.y);
                   const midX = (start.x + end.x) / 2;
                   const midY = (start.y + end.y) / 2 - (dist * 0.4);
                   p.bezier(start.x, start.y, midX, midY, midX, midY, end.x, end.y);
                   
                   const bx = p.bezierPoint(start.x, midX, midX, end.x, t);
                   const by = p.bezierPoint(start.y, midY, midY, end.y, t);
                   p.fill(255); p.noStroke(); p.circle(bx, by, 7);
                }
             }
          });
        }
        p.pop();
      };

      p.windowResized = () => {
        if (!containerRef.current) return;
        const rect = containerRef.current.getBoundingClientRect();
        p.resizeCanvas(rect.width, rect.height);
      };
    };

    p5InstanceRef.current = new p5(sketch, containerRef.current);
    return () => p5InstanceRef.current?.remove();
  }, [step, data, index]);

  const handleSpeak = () => {
    window.speechSynthesis.cancel();
    let text = typeof step?.narration === 'string' ? step.narration : step?.narration?.en || step?.description || "";
    if (text) {
      const utter = new SpeechSynthesisUtterance(text);
      window.speechSynthesis.speak(utter);
    }
  };

  return (
    <div className="bg-slate-900/40 border border-white/5 rounded-[2.5rem] p-6 md:p-8 mb-12 backdrop-blur-md shadow-2xl animate-in fade-in slide-in-from-bottom-4">
      <div className="flex flex-col md:flex-row justify-between items-start mb-6 gap-4">
        <div className="flex-1">
          <div className="flex items-center gap-3 mb-2">
             <span className="bg-violet-600/20 text-violet-400 border border-violet-500/20 px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest">Step {index + 1}</span>
             <h2 className="text-xl md:text-3xl font-bold text-white tracking-tight">{step?.title || "Reaction Process"}</h2>
          </div>
          <p className="text-slate-400 text-sm md:text-lg font-medium leading-snug">{step?.description}</p>
        </div>
        <button onClick={handleSpeak} className="p-4 bg-violet-600/10 hover:bg-violet-600/20 text-violet-400 rounded-2xl transition-all border border-violet-500/20 active:scale-95 group">
          <i className="bi bi-megaphone-fill text-xl group-hover:scale-110 transition-transform"></i>
        </button>
      </div>
      <div className="relative rounded-[2rem] border border-white/10 overflow-hidden bg-[#020305] w-full h-[450px] md:h-[550px]" ref={containerRef}>
        <div className="absolute top-4 right-4 flex flex-col gap-2 z-10">
          <button onClick={() => p5InstanceRef.current.view.zoom *= 1.2} className="w-10 h-10 bg-white/5 rounded-xl text-white border border-white/10 flex items-center justify-center hover:bg-white/10"><i className="bi bi-plus-lg"></i></button>
          <button onClick={() => p5InstanceRef.current.view.zoom /= 1.2} className="w-10 h-10 bg-white/5 rounded-xl text-white border border-white/10 flex items-center justify-center hover:bg-white/10"><i className="bi bi-dash-lg"></i></button>
          <button onClick={() => p5InstanceRef.current.resetView()} className="w-10 h-10 bg-white/5 rounded-xl text-white border border-white/10 flex items-center justify-center hover:bg-white/10"><i className="bi bi-arrow-counterclockwise"></i></button>
        </div>
        <div className="absolute bottom-4 left-4 text-[10px] text-white/30 font-mono">
          DRAG TO PAN • SCROLL TO ZOOM
        </div>
      </div>
    </div>
  );
};

export default P5Canvas;
