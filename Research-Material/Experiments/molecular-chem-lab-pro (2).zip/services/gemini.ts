
import { GoogleGenAI } from "@google/genai";
import { MechanismData } from "../types";

const SYSTEM_PROMPT = `Act as a world-class Organic Chemist and Molecular Architect. 
Your goal: Generate or refine high-fidelity scientific JSON for a mechanism visualizer.

CRITICAL VISUAL RULES:
1. SHORTHAND GROUPS: Use functional group shorthand labels (e.g., "CH3", "OH", "Ph", "COOH", "CN") for non-participating groups to keep the canvas clean.
2. DETAILED CENTERS: Only expand individual atoms (C, H, O, etc.) for the specific centers involved in bond breaking or forming.
3. SPATIAL ACCURACY: Standard bond lengths are ~70 units. Use proper geometry: 109.5° for sp3, 120° for sp2, 180° for linear. Ensure no overlapping atoms.
4. COORDINATES: Molecules should be spaced roughly 150-250 units apart if they are separate species.
5. HIDDEN STATES: Use "hidden": true for leaving groups that have departed or reagents not yet present.

FULL POWERED JSON EXAMPLE (SN2 REACTION):
{
  "meta": { "reactionName": "SN2: Hydroxide + Methyl Bromide" },
  "molecules": {
    "substrate": {
      "position": [0, 0],
      "atoms": [
        { "id": "c1", "element": "C", "position": [0, 0] },
        { "id": "br", "element": "Br", "position": [70, 0] },
        { "id": "h1", "element": "H", "position": [-25, -50] },
        { "id": "h2", "element": "H", "position": [-25, 50] },
        { "id": "h3", "element": "H", "position": [-40, 0] }
      ],
      "bonds": [
        { "from": "c1", "to": "br", "type": "single" },
        { "from": "c1", "to": "h1", "type": "single" },
        { "from": "c1", "to": "h2", "type": "single" },
        { "from": "c1", "to": "h3", "type": "single" }
      ]
    },
    "nuc": {
      "position": [-180, 0],
      "atoms": [{ "id": "o1", "element": "OH", "position": [0, 0], "charge": -1 }],
      "bonds": []
    }
  },
  "mechanism": [
    {
      "step": 0,
      "title": "Initial State",
      "description": "The hydroxide nucleophile approaches the electrophilic carbon from the backside.",
      "displayMolecules": ["substrate", "nuc"],
      "animationHints": [
        { "type": "curlyArrow", "from": "nuc:o1", "to": "substrate:c1" }
      ]
    },
    {
      "step": 1,
      "title": "Transition State & Product",
      "description": "The C-Br bond breaks as the C-OH bond forms, causing an inversion of configuration.",
      "displayMolecules": ["substrate", "nuc"],
      "animationHints": [
        { "type": "curlyArrow", "from": "substrate:c1", "to": "substrate:br" }
      ],
      "resultingState": {
        "molecules": {
          "substrate": {
            "atoms": [
              { "id": "br", "position": [140, 0], "charge": -1 },
              { "id": "h1", "position": [25, -50] },
              { "id": "h2", "position": [25, 50] },
              { "id": "h3", "position": [40, 0] }
            ],
            "bonds": [
              { "from": "c1", "to": "br", "hidden": true }
            ]
          },
          "nuc": {
            "position": [-70, 0],
            "atoms": [{ "id": "o1", "charge": 0 }],
            "bonds": [{ "from": "o1", "to": "substrate:c1", "type": "single" }]
          }
        }
      }
    }
  ]
}

REFINEMENT MODE:
If provided with 'previousData', you MUST fix the errors identified in 'feedback'. Fix overlaps, correct chemical logic, or improve layout while adhering to the same structure.`;

export const analyzeReaction = async (
  input: string, 
  imageData?: string, 
  previousData?: MechanismData, 
  feedback?: string
): Promise<MechanismData | null> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  
  let promptText = `Identify and visualize the mechanism for: ${input || "the reaction in the image"}. Ensure the coordinates are well-spaced and the chemical logic is sound.`;
  
  if (previousData) {
    promptText = `REFINEMENT REQUEST:
The user is unsatisfied with the previous generation. 
PREVIOUS JSON: ${JSON.stringify(previousData)}
USER FEEDBACK: ${feedback || "Automatically fix visual overlaps, incorrect bond angles, or errors in the mechanism flow."}
Please return a corrected version of the JSON following the high-powered example structure.`;
  }

  const contents: any[] = [{ text: promptText }];
  
  if (imageData) {
    const base64Data = imageData.split(',')[1] || imageData;
    contents.push({
      inlineData: {
        mimeType: 'image/png',
        data: base64Data,
      },
    });
  }

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: { parts: contents },
      config: {
        systemInstruction: SYSTEM_PROMPT,
        responseMimeType: "application/json",
      },
    });

    const text = response.text;
    if (!text) return null;
    
    const jsonStr = text.replace(/```json/g, '').replace(/```/g, '').trim();
    const data = JSON.parse(jsonStr) as MechanismData;
    
    // Final check to ensure basic structure exists to avoid frontend crashes
    if (!data.meta || !data.molecules || !data.mechanism) {
      console.error("Incomplete JSON generated by AI");
      return null;
    }
    
    return data;
  } catch (error) {
    console.error("Gemini API Error:", error);
    return null;
  }
};
