# Molecular Lab Canvas Pro

An advanced, AI-powered chemistry visualization platform that transforms complex organic reaction mechanisms into interactive, animated molecular simulations.

## 🚀 How to Run
1. **Environment Setup**: Ensure you have a valid Gemini API Key. This application expects the key to be provided via `process.env.API_KEY`.
2. **Launch**: Open `index.html` in any modern web browser.
3. **Usage**:
   - Click **AI Studio** to generate a mechanism.
   - Enter a reaction name (e.g., "Aldol Condensation") or upload a handwritten mechanism photo.
   - Use the **Manual JSON Architect** to paste or load example mechanism structures directly.

## 🧠 How it Works
- **Interpretation**: The app uses **Gemini 3 Flash** to parse natural language or images into a precise scientific JSON schema.
- **Visualization**: A custom-built **p5.js** engine renders the atoms and bonds using standard CPK coloring and sp3/sp2/sp geometry.
- **Animation**: The engine interprets "Animation Hints" to draw electron flow (curly arrows), bond breaks, and state transitions in real-time.
- **Narration**: Integrated Web Speech API provides multilingual explanations for each step.

## ✨ Key Benefits
- **Visual Learning**: Helps students and researchers "see" the electron flow that is often lost in static textbook diagrams.
- **Instant Prototyping**: Quickly generate a visual guide for any named reaction without manual drawing.
- **Accessibility**: Includes high-contrast modes, zoomable canvases, and audio narration.
- **Interactive**: Users can pan, zoom, and inspect molecular geometry from any angle.
