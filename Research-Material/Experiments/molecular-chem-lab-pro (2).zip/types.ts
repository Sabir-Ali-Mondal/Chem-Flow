
export type Vector2D = { x: number; y: number } | [number, number];

export interface Atom {
  id: string;
  element: string;
  position: Vector2D;
  charge?: number;
  color?: string; // Optional custom color like "255, 0, 0"
  hidden?: boolean;
}

export interface Bond {
  from: string;
  to: string;
  type: 'single' | 'double' | 'triple';
  hidden?: boolean;
}

export interface Molecule {
  position: Vector2D;
  atoms: Atom[];
  bonds: Bond[];
  hidden?: boolean;
}

export type AnimationHint = 
  | { type: 'curlyArrow'; from: string; to: string }
  | { type: 'bondMove'; from: string; to: string; bond: string; typeChange?: 'single' | 'double' | 'triple' }
  | { type: 'bondBreak'; from: string; to: string }
  | { type: 'atomMove'; atomId: string; to: Vector2D }; // Specific hint for rotations/movements

export interface ResultingState {
  molecules: {
    [molId: string]: Partial<Omit<Molecule, 'atoms' | 'bonds'>> & {
      atoms?: Array<Partial<Atom> & { id: string }>;
      bonds?: Array<Partial<Bond> & { from: string; to: string }>;
    };
  };
}

export interface MechanismStep {
  step: number;
  title: string;
  description: string;
  narration?: string | { [key: string]: string };
  displayMolecules: string[];
  animationHints?: AnimationHint[];
  resultingState?: ResultingState;
}

export interface MechanismData {
  meta: {
    reactionName: string;
  };
  molecules: {
    [key: string]: Molecule;
  };
  mechanism: MechanismStep[];
}
